package com.example.demo;

public class Test {
    public static String xx() {
        
        return "";
    }

}